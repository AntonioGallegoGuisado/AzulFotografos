
var CKEDITOR_BASEPATH = '/assets/blogo/ckeditor/';
